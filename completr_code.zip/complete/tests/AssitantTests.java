package tests;

import classes.*;

import org.junit.jupiter.api.Test;

public class AssitantTests {
    @Test
    public void constructorTest(){
        Assistant test = new Assistant("name1", 32, "adress1");
    }
}
