package classes;

import interfaces.I_Assistant;

public class Assistant extends Person implements I_Assistant {
	
	public Assistant(String name, int age, String address) {
		super();
	}
}
