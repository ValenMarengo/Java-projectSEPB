package interfaces;

public interface I_Assistant extends I_Person {
}
