package interfaces;

public interface I_Person {
    String getName();
    int getAge();
    String getAddress();

}
